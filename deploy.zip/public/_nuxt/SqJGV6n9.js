import{j as c,c as s,o as r,a as e,e as d,f as o,F as p,r as u,t as n}from"#entry";import{_ as f}from"./DlAUqK2U.js";const m={class:"mx-auto w-full max-w-[72ch] px-5 sm:px-6 py-6 sm:py-10 bg-gray-800 rounded-2xl shadow-2xl ring-1 ring-white/5"},g={class:"mt-7 sm:mt-9 space-y-7"},b={class:"text-base sm:text-lg font-semibold text-white"},y={class:"text-[15.5px] sm:text-base leading-7 text-gray-200"},h={class:"bg-gray-900/80 border border-gray-700/70 rounded-xl p-4 overflow-x-auto"},x={class:"text-sm leading-6 font-mono text-green-400 whitespace-pre"},v=c({__name:"ClipboardSnippets",setup(w){const l=[{title:"Debounce Function",description:"Limits how often a function is executed. Useful for input, scroll, or resize events.",code:`function debounce(fn, delay) {
  let timeout
  return (...args) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => fn(...args), delay)
  }
}`},{title:"Throttle Function",description:"Ensures a function is only called once every X milliseconds.",code:`function throttle(fn, limit) {
  let inThrottle
  return (...args) => {
    if (!inThrottle) {
      fn(...args)
      inThrottle = true
      setTimeout(() => { inThrottle = false }, limit)
    }
  }
}`},{title:"Deep Clone",description:"Safely clones nested objects and arrays using JSON (works for most use cases).",code:`function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj))
}`},{title:"Copy to Clipboard",description:"Copy any text string directly to the clipboard.",code:`async function copyToClipboard(text) {
  try { await navigator.clipboard.writeText(text) } catch {}
}`},{title:"Check if Object is Empty",description:"Utility to validate if an object has no keys.",code:`function isEmpty(obj) {
  return Object.keys(obj).length === 0
}`},{title:"Generate Random ID",description:"Generate unique IDs (not UUIDs, but useful for UI components).",code:`function randomID(length = 8) {
  return Math.random().toString(36).slice(2, 2 + length)
}`},{title:"Sleep / Delay in Async Functions",description:"Pause execution inside an async function.",code:`function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}`},{title:"Group Array by Property",description:"Group an array of objects by a shared key.",code:`function groupBy(arr, key) {
  return arr.reduce((acc, obj) => {
    const val = obj[key]
    ;(acc[val] ||= []).push(obj)
    return acc
  }, {})
}`},{title:"Capitalize First Letter",description:"Format strings by capitalizing the first character.",code:`function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1)
}`},{title:"Clamp a Number Between Two Values",description:"Ensure a number stays within bounds.",code:`function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max)
}`}];return(_,t)=>(r(),s("article",m,[t[2]||(t[2]=e("section",{class:"mt-6 sm:mt-8 space-y-5"},[e("p",{class:"text-[15.5px] sm:text-base leading-7 text-gray-200"},[o(" As developers, we often rewrite the same utilities. Here’s a curated list of "),e("strong",{class:"text-white"},"10 high-value JavaScript snippets"),o(" you can paste into your next project: debouncing, throttling, string formatting, and array manipulation. ")])],-1)),e("section",g,[(r(),s(p,null,u(l,(i,a)=>e("div",{key:a,class:"space-y-3"},[e("h2",b,n(a+1)+". "+n(i.title),1),e("p",y,n(i.description),1),e("div",h,[e("pre",x,[t[0]||(t[0]=o("",-1)),e("code",null,n(i.code),1),t[1]||(t[1]=o(`
          `,-1))])])])),64))]),t[3]||(t[3]=d('<section class="mt-10 sm:mt-12 space-y-3" data-v-e527af82><h2 class="text-base sm:text-lg font-semibold text-white" data-v-e527af82>📌 Final Tip</h2><p class="text-[15.5px] sm:text-base leading-7 text-gray-200" data-v-e527af82> Supercharge your workflow with a clipboard manager like <a class="underline underline-offset-2 decoration-indigo-400 hover:decoration-indigo-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 rounded" href="https://espanso.org" target="_blank" rel="noopener noreferrer" aria-label="Espanso clipboard manager (opens in a new tab)" data-v-e527af82>Espanso</a>, <a class="underline underline-offset-2 decoration-indigo-400 hover:decoration-indigo-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 rounded" href="https://clipy-app.com" target="_blank" rel="noopener noreferrer" aria-label="Clipy clipboard manager (opens in a new tab)" data-v-e527af82>Clipy</a>, or <a class="underline underline-offset-2 decoration-indigo-400 hover:decoration-indigo-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 rounded" href="https://raycast.com" target="_blank" rel="noopener noreferrer" aria-label="Raycast clipboard manager (opens in a new tab)" data-v-e527af82>Raycast</a>. Keeping snippets ready-to-go will save you <strong class="text-white" data-v-e527af82>hours every week</strong>. </p></section>',1))]))}}),j=Object.assign(f(v,[["__scopeId","data-v-e527af82"]]),{__name:"ArticlesSnippetClipboardSnippets"});export{j as default};
