import{_ as I}from"./D76SP8G7.js";import{j as L,k as g,d as x,D as A,c as l,o as r,a as e,p as b,g as O,F as h,r as _,t as i,y as f,z as C,n as B,a7 as E,f as k,e as z}from"#entry";import{_ as J}from"./DlAUqK2U.js";import"./R_1w5LGs.js";const M={class:"space-y-6 bg-gray-800 p-6 sm:p-8 rounded-2xl shadow-xl text-white"},H={class:"card"},W={class:"flex flex-wrap gap-2"},F=["onClick","title"],U={class:"card space-y-4"},Y={class:"flex items-center justify-between gap-3 flex-wrap"},$={class:"flex items-center gap-2"},q={class:"space-y-4"},Q={class:"text-sm font-semibold text-gray-300 uppercase tracking-wide"},K={class:"grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2"},X=["value"],Z={class:"text-sm"},ee={class:"card space-y-3"},te={key:0,class:"card space-y-3"},ae={class:"flex items-center justify-between gap-3 flex-wrap"},se={class:"flex items-center gap-3"},ne={class:"text-xs px-2 py-1 bg-indigo-800/30 text-indigo-400 rounded-full font-medium"},oe={class:"relative"},le={class:"mono-box max-h-[500px] overflow-auto text-xs"},re={class:"flex items-center justify-between text-xs text-gray-400"},ie={class:"flex gap-4"},ce={key:0},de={key:0,class:"text-green-400 font-medium"},pe={class:"card"},me={class:"flex items-center justify-between mb-2"},ue={key:0,class:"space-y-2 text-sm text-gray-300"},ge=L({__name:"GitignoreGenerator",setup(ve){const n=g([]),c=g(""),p=g(""),y=g(!1),m=g(!1),S=[{name:"Node.js",templates:["Node","npm","Yarn"]},{name:"Python",templates:["Python","JupyterNotebooks","virtualenv"]},{name:"Java",templates:["Java","Maven","Gradle"]},{name:"React",templates:["Node","npm","Yarn","VisualStudioCode"]},{name:"Vue.js",templates:["Node","npm","Yarn","VisualStudioCode"]},{name:"Go",templates:["Go"]},{name:"Rust",templates:["Rust"]},{name:"Full Stack",templates:["Node","Python","VisualStudioCode","macOS","Windows","Linux"]}],v=[{name:"Languages",templates:[{name:"Node",content:`# Node
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*
lerna-debug.log*
.pnpm-debug.log*
.npm
.eslintcache
.node_repl_history
*.tgz
.yarn-integrity
.env
.env.test
.env.production
.env.local
.cache`},{name:"Python",content:`# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST
*.manifest
*.spec
pip-log.txt
pip-delete-this-directory.txt
htmlcov/
.tox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
.hypothesis/
.pytest_cache/
*.mo
*.pot
*.log
local_settings.py
instance/
.webassets-cache
.scrapy
docs/_build/
target/
.ipynb_checkpoints
.python-version
celerybeat-schedule
*.sage.py
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/`},{name:"Java",content:`# Java
*.class
*.log
*.jar
*.war
*.nar
*.ear
*.zip
*.tar.gz
*.rar
hs_err_pid*`},{name:"Go",content:`# Go
*.exe
*.exe~
*.dll
*.so
*.dylib
*.test
*.out
go.work
vendor/`},{name:"Rust",content:`# Rust
debug/
target/
Cargo.lock
**/*.rs.bk
*.pdb`},{name:"PHP",content:`# PHP
vendor/
node_modules/
npm-debug.log
yarn-error.log
.env
.env.backup
.phpunit.result.cache
Homestead.json
Homestead.yaml
auth.json
*.cache
*.log`},{name:"Ruby",content:`# Ruby
*.gem
*.rbc
/.config
/coverage/
/InstalledFiles
/pkg/
/spec/reports/
/spec/examples.txt
/test/tmp/
/test/version_tmp/
/tmp/
*.bundler
.bundle/
lib/bundler/man/
vendor/bundle
.rvmrc
.ruby-version
.ruby-gemset`},{name:"C++",content:`# C++
*.o
*.ko
*.obj
*.elf
*.exe
*.out
*.app
*.i*86
*.x86_64
*.hex
*.dSYM/
*.su
*.idb
*.pdb`}]},{name:"Frameworks",templates:[{name:"React",content:`# React
.DS_Store
node_modules
/build
.env.local
.env.development.local
.env.test.local
.env.production.local
npm-debug.log*
yarn-debug.log*
yarn-error.log*`},{name:"Vue",content:`# Vue
.DS_Store
node_modules
/dist
.env.local
.env.*.local
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*`},{name:"Next.js",content:`# Next.js
.next
out
build
dist
.vercel
.env*.local`},{name:"Django",content:`# Django
*.log
*.pot
*.pyc
__pycache__/
local_settings.py
db.sqlite3
db.sqlite3-journal
/media
/static
.env`},{name:"Laravel",content:`# Laravel
/node_modules
/public/hot
/public/storage
/storage/*.key
/vendor
.env
.env.backup
.phpunit.result.cache
Homestead.json
Homestead.yaml
npm-debug.log
yarn-error.log`}]},{name:"Build Tools",templates:[{name:"npm",content:`# npm
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.npm
.eslintcache`},{name:"Yarn",content:`# Yarn
.yarn/*
!.yarn/patches
!.yarn/plugins
!.yarn/releases
!.yarn/sdks
!.yarn/versions
.pnp.*`},{name:"Maven",content:`# Maven
target/
pom.xml.tag
pom.xml.releaseBackup
pom.xml.versionsBackup
pom.xml.next
release.properties
dependency-reduced-pom.xml
buildNumber.properties
.mvn/timing.properties`},{name:"Gradle",content:`# Gradle
.gradle
build/
!gradle/wrapper/gradle-wrapper.jar
!**/src/main/**/build/
!**/src/test/**/build/`},{name:"Webpack",content:`# Webpack
dist/
build/
.cache/
node_modules/`},{name:"Vite",content:`# Vite
dist
dist-ssr
*.local`}]},{name:"Operating Systems",templates:[{name:"macOS",content:`# macOS
.DS_Store
.AppleDouble
.LSOverride
Icon
._*
.DocumentRevisions-V100
.fseventsd
.Spotlight-V100
.TemporaryItems
.Trashes
.VolumeIcon.icns
.com.apple.timemachine.donotpresent
.AppleDB
.AppleDesktop
Network Trash Folder
Temporary Items
.apdisk`},{name:"Windows",content:`# Windows
Thumbs.db
Thumbs.db:encryptable
ehthumbs.db
ehthumbs_vista.db
*.stackdump
[Dd]esktop.ini
$RECYCLE.BIN/
*.cab
*.msi
*.msix
*.msm
*.msp
*.lnk`},{name:"Linux",content:`# Linux
*~
.fuse_hidden*
.directory
.Trash-*
.nfs*`}]},{name:"IDEs & Editors",templates:[{name:"VisualStudioCode",content:`# VSCode
.vscode/*
!.vscode/settings.json
!.vscode/tasks.json
!.vscode/launch.json
!.vscode/extensions.json
*.code-workspace
.history/`},{name:"JetBrains",content:`# JetBrains
.idea/
*.iml
*.iws
*.ipr
out/
.idea_modules/
atlassian-ide-plugin.xml
com_crashlytics_export_strings.xml
crashlytics.properties
crashlytics-build.properties
fabric.properties`},{name:"SublimeText",content:`# Sublime Text
*.tmlanguage.cache
*.tmPreferences.cache
*.stTheme.cache
*.sublime-workspace
*.sublime-project
sftp-config.json
Package Control.last-run
Package Control.ca-list
Package Control.ca-bundle
Package Control.system-ca-bundle
Package Control.cache/
Package Control.ca-certs/`},{name:"Vim",content:`# Vim
[._]*.s[a-v][a-z]
[._]*.sw[a-p]
[._]s[a-rt-v][a-z]
[._]ss[a-gi-z]
[._]sw[a-p]
Session.vim
Sessionx.vim
.netrwhist
*~
tags
[._]*.un~`}]},{name:"Other Tools",templates:[{name:"Docker",content:`# Docker
*.dockerignore
docker-compose.override.yml`},{name:"Git",content:`# Git
*.orig
*.swp
*.swo`},{name:"JupyterNotebooks",content:`# Jupyter Notebooks
.ipynb_checkpoints
*/.ipynb_checkpoints/*
profile_default/
ipython_config.py`},{name:"virtualenv",content:`# virtualenv
.venv
venv/
ENV/
env.bak/
venv.bak/`}]}],j=x(()=>{if(!p.value.trim())return v;const s=p.value.toLowerCase();return v.map(t=>({...t,templates:t.templates.filter(o=>o.name.toLowerCase().includes(s))})).filter(t=>t.templates.length>0)}),d=x(()=>{if(n.value.length===0&&!c.value.trim())return"";let s=`# Generated by CodeHelper.me - .gitignore Generator
`;return s+=`# Date: ${new Date().toISOString().split("T")[0]}

`,n.value.forEach(t=>{const o=v.flatMap(a=>a.templates).find(a=>a.name===t);o&&(s+=o.content+`

`)}),c.value.trim()&&(s+=`# Custom Rules
`,s+=c.value.trim()+`
`),s.trim()}),w=x(()=>{const s=d.value.split(`
`).filter(o=>{const a=o.trim();return a&&!a.startsWith("#")}),t=n.value.length+(c.value.trim()?1:0);return{patterns:s.length,sections:t}});function V(s){n.value=s}function G(){n.value=v.flatMap(s=>s.templates).map(s=>s.name)}function N(){n.value=[]}function T(){n.value=[],c.value="",p.value=""}function P(){d.value&&(navigator.clipboard.writeText(d.value),y.value=!0,setTimeout(()=>y.value=!1,1200))}function D(){if(!d.value)return;const s=new Blob([d.value],{type:"text/plain"}),t=URL.createObjectURL(s),o=document.createElement("a");o.href=t,o.download=".gitignore",o.click(),URL.revokeObjectURL(t)}return A([n,c],()=>{},{deep:!0}),(s,t)=>{const o=I;return r(),l("div",M,[e("div",{class:"card flex items-center justify-between gap-3 flex-wrap"},[t[4]||(t[4]=e("div",null,[e("h2",{class:"text-2xl font-semibold"},"📝 .gitignore Generator"),e("p",{class:"text-sm text-gray-400 mt-1"},"Generate .gitignore files for your projects with pre-built templates")],-1)),e("div",{class:"flex items-center gap-2"},[e("button",{class:"btn",onClick:T},"Clear All")])]),e("div",H,[t[5]||(t[5]=e("label",{class:"label mb-3"},"🚀 Quick Start (Popular Presets)",-1)),e("div",W,[(r(),l(h,null,_(S,a=>e("button",{key:a.name,class:"btn-small",onClick:u=>V(a.templates),title:`Apply ${a.name} preset`},i(a.name),9,F)),64))])]),e("div",U,[e("div",Y,[t[6]||(t[6]=e("label",{class:"label"},"📚 Select Templates",-1)),e("div",$,[f(e("input",{"onUpdate:modelValue":t[0]||(t[0]=a=>p.value=a),type:"text",placeholder:"Search templates...",class:"input w-48"},null,512),[[C,p.value]]),e("button",{class:"btn text-xs",onClick:G},"Select All"),e("button",{class:"btn text-xs",onClick:N},"Deselect All")])]),e("div",q,[(r(!0),l(h,null,_(j.value,a=>(r(),l("div",{key:a.name,class:"space-y-2"},[e("h3",Q,i(a.name)+" ("+i(a.templates.length)+") ",1),e("div",K,[(r(!0),l(h,null,_(a.templates,u=>(r(),l("label",{key:u.name,class:B(["inline-flex items-center gap-2 cursor-pointer bg-gray-800 p-2 rounded border border-gray-700 hover:border-indigo-500 transition-colors",{"border-indigo-500 bg-indigo-900/20":n.value.includes(u.name)}])},[f(e("input",{type:"checkbox",value:u.name,"onUpdate:modelValue":t[1]||(t[1]=R=>n.value=R)},null,8,X),[[E,n.value]]),e("span",Z,i(u.name),1)],2))),128))])]))),128))])]),e("div",ee,[t[7]||(t[7]=e("label",{class:"label"},"✏️ Custom Rules (Optional)",-1)),f(e("textarea",{"onUpdate:modelValue":t[2]||(t[2]=a=>c.value=a),placeholder:"Add your custom .gitignore rules here, one per line...",class:"input font-mono resize-y min-h-[100px]",spellcheck:"false"},null,512),[[C,c.value]]),t[8]||(t[8]=e("p",{class:"text-xs text-gray-400"},[k(" Example: "),e("code",{class:"bg-gray-800 px-1 rounded"},"*.log"),k(", "),e("code",{class:"bg-gray-800 px-1 rounded"},"/dist/"),k(", "),e("code",{class:"bg-gray-800 px-1 rounded"},"!important.txt")],-1))]),d.value?(r(),l("div",te,[e("div",ae,[e("div",se,[t[9]||(t[9]=e("label",{class:"label"},"📄 Generated .gitignore",-1)),e("span",ne,i(w.value.patterns)+" patterns • "+i(w.value.sections)+" sections ",1)]),e("div",{class:"flex items-center gap-2"},[e("button",{class:"btn",onClick:P,title:"Copy to clipboard"}," 📋 Copy "),e("button",{class:"btn",onClick:D,title:"Download .gitignore"}," 💾 Download ")])]),e("div",oe,[e("pre",le,i(d.value),1)]),e("div",re,[e("div",ie,[e("span",null,i(n.value.length)+" template(s) selected",1),c.value.trim()?(r(),l("span",ce,"+ Custom rules")):b("",!0)]),e("div",null,[y.value?(r(),l("span",de,"✓ Copied!")):b("",!0)])])])):b("",!0),e("div",pe,[e("div",me,[t[10]||(t[10]=e("p",{class:"label"},"💡 Tips & Info",-1)),e("button",{class:"btn-small",onClick:t[3]||(t[3]=a=>m.value=!m.value)},i(m.value?"▼":"▶")+" "+i(m.value?"Hide":"Show"),1)]),m.value?(r(),l("div",ue,[...t[11]||(t[11]=[z('<p data-v-52cae94c><strong data-v-52cae94c>What is .gitignore?</strong></p><p data-v-52cae94c>A .gitignore file specifies files and directories that Git should ignore. This prevents unnecessary files from being committed to your repository.</p><p class="mt-3" data-v-52cae94c><strong data-v-52cae94c>Common patterns:</strong></p><ul class="list-disc list-inside ml-4 space-y-1" data-v-52cae94c><li data-v-52cae94c><code class="bg-gray-800 px-1 rounded" data-v-52cae94c>*.log</code> - Ignore all .log files</li><li data-v-52cae94c><code class="bg-gray-800 px-1 rounded" data-v-52cae94c>/dist/</code> - Ignore dist directory in root</li><li data-v-52cae94c><code class="bg-gray-800 px-1 rounded" data-v-52cae94c>node_modules/</code> - Ignore node_modules everywhere</li><li data-v-52cae94c><code class="bg-gray-800 px-1 rounded" data-v-52cae94c>!important.txt</code> - Negate pattern (don&#39;t ignore this file)</li></ul><p class="mt-3" data-v-52cae94c><strong data-v-52cae94c>Where to place it:</strong></p><p data-v-52cae94c>Place the <code class="bg-gray-800 px-1 rounded" data-v-52cae94c>.gitignore</code> file in the root of your Git repository.</p>',6)])])):b("",!0)]),O(o)])}}}),_e=Object.assign(J(ge,[["__scopeId","data-v-52cae94c"]]),{__name:"ToolsGeneratorGitignoreGenerator"});export{_e as default};
